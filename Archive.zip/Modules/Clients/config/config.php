<?php

return [
    'name' => 'Clients',
];
