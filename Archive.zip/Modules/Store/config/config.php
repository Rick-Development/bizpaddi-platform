<?php

return [
    'name' => 'Store',
];
