<?php

return [
    'name' => 'Subsidiaries',
];
