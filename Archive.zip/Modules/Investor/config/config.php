<?php

return [
    'name' => 'Investor',
];
