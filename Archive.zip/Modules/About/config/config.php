<?php

return [
    'name' => 'About',
];
