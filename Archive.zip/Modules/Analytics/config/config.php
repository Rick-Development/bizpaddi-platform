<?php

return [
    'name' => 'Analytics',
];
