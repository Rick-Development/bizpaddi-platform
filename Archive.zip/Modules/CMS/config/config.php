<?php

return [
    'name' => 'CMS',
];
