<?php

return [
    'name' => 'Careers',
];
