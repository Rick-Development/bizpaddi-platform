<?php

return [
    'name' => 'ClientPortal',
];
