<?php

return [
    'name' => 'Legal',
];
