<?php

return [
    'name' => 'Communications',
];
