<?php

return [
    'name' => 'Home',
];
